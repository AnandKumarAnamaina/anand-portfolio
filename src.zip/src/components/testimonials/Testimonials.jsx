import { useState } from "react";

const testimonials = [
  {
    id: 1,
    name: "Seepathi Ram Sai",
    role: "B.Tech Student",
    course: "Power BI Internship",
    avatar: "SR",
    rating: 5,
    feedback:
      "My experience in this program was highly rewarding and insightful. The training was well-structured, practical, and focused on real-world applications of data analytics and business intelligence. Through hands-on projects and expert guidance, I was able to strengthen my skills in Power BI, data modeling, DAX, and dashboard development. The support and mentorship provided throughout the internship helped me gain confidence in solving business problems using data-driven approaches. I am especially grateful to Infinity Code Nexus and Anand Kumar Sir for their continuous guidance, encouragement, and commitment to helping learners grow professionally.",
  },
  {
    id: 2,
    name: "Kanamathareddy Chethan Reddy",
    role: "B.Tech Student",
    course: "Power BI Internship",
    avatar: "CR",
    rating: 5,
    feedback:
      "The Power BI Internship Program at Infinity Code Nexus was a valuable learning experience that helped me strengthen my skills in data analytics and business intelligence. The practical assignments, project-based learning approach, and continuous guidance from Anand Sir enabled me to build confidence in creating professional Power BI dashboards and applying data-driven decision-making techniques. I am grateful to Infinity Code Nexus for providing this opportunity and helping me enhance my technical and analytical skills.",
  },
  {
    id: 3,
    name: "Macha Ramyasree",
    role: "B.Tech Student",
    course: "Power BI Master Class",
    avatar: "MR",
    rating: 5,
    feedback:
      "My learning experience with Infinity Code Nexus was excellent. The program provided hands-on training in Power BI, data analysis, DAX, and dashboard development, helping me build confidence and complete my first end-to-end analytics project successfully. I am grateful to my mentor, Mr. Anand Kumar Anamaina, for his guidance and support throughout the journey.",
  },
];

export default function Testimonials() {
  const [expanded, setExpanded] = useState({});
  const [visible, setVisible] = useState(6);

  const toggle = (id) => {
    setExpanded((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  return (
    <section
      id="testimonials"
      className="py-24 bg-gradient-to-b from-slate-50 via-white to-slate-100"
    >
      <div className="max-w-7xl mx-auto px-6">
        {/* Heading */}

        <div className="text-center mb-16">
          <span className="inline-flex px-5 py-2 rounded-full bg-blue-100 text-blue-700 font-semibold">
            Testimonials
          </span>

          <h2 className="mt-6 text-5xl font-bold text-slate-900">
            What My Students Say
          </h2>

          <p className="mt-5 max-w-3xl mx-auto text-lg text-slate-600 leading-8">
            Feedback shared by participants of my Power BI Master Class and
            Internship Program.
          </p>
        </div>

        {/* Statistics */}

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
          <div className="bg-white rounded-3xl shadow-md p-8 text-center">
            <h3 className="text-5xl">⭐</h3>
            <p className="text-3xl font-bold mt-3">4.9/5</p>
            <p className="text-slate-500 mt-2">Average Rating</p>
          </div>

          <div className="bg-white rounded-3xl shadow-md p-8 text-center">
            <h3 className="text-5xl">👨‍🎓</h3>
            <p className="text-3xl font-bold mt-3">50+</p>
            <p className="text-slate-500 mt-2">Participants</p>
          </div>

          <div className="bg-white rounded-3xl shadow-md p-8 text-center">
            <h3 className="text-5xl">📊</h3>
            <p className="text-3xl font-bold mt-3">15 Days</p>
            <p className="text-slate-500 mt-2">Master Class</p>
          </div>

          <div className="bg-white rounded-3xl shadow-md p-8 text-center">
            <h3 className="text-5xl">⏰</h3>
            <p className="text-3xl font-bold mt-3">45+</p>
            <p className="text-slate-500 mt-2">Training Hours</p>
          </div>
        </div>

        {/* Cards */}

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.slice(0, visible).map((item) => (
            <div
              key={item.id}
              className="group bg-white rounded-3xl border border-slate-200 shadow-lg hover:shadow-2xl hover:-translate-y-2 transition-all duration-300 overflow-hidden"
            >
              <div className="h-2 bg-gradient-to-r from-blue-600 via-purple-500 to-pink-500"></div>

              <div className="p-8">
                {/* Avatar */}

                <div className="flex items-center justify-between mb-6">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 text-white flex items-center justify-center text-xl font-bold group-hover:scale-110 transition">
                    {item.avatar}
                  </div>

                  <div className="text-yellow-500 text-xl">
                    {"⭐".repeat(item.rating)}
                  </div>
                </div>

                <h3 className="text-xl font-bold text-slate-900">
                  {item.name}
                </h3>

                <p className="text-slate-500">{item.role}</p>

                <span className="inline-block mt-3 px-4 py-1 rounded-full bg-blue-100 text-blue-700 text-sm font-medium">
                  {item.course}
                </span>

                <div className="mt-6 text-5xl text-blue-100 leading-none">
                  ❝
                </div>

                <p className="mt-4 text-slate-600 leading-8 italic">
                  "
                  {expanded[item.id]
                    ? item.feedback
                    : item.feedback.substring(0, 180) + "..."}
                  "
                </p>

                <button
                  onClick={() => toggle(item.id)}
                  className="mt-6 text-blue-600 font-semibold hover:text-blue-800 transition"
                >
                  {expanded[item.id] ? "Show Less ↑" : "Read More →"}
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Load More */}

        {visible < testimonials.length && (
          <div className="text-center mt-14">
            <button
              onClick={() => setVisible(testimonials.length)}
              className="px-8 py-4 rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold shadow-lg hover:scale-105 transition"
            >
              View More Reviews
            </button>
          </div>
        )}
      </div>
    </section>
  );
}