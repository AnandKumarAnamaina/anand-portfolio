const testimonials = [
  {
    id: 1,
    name: "Seepathi Ram Sai",
    role: "B.Tech Student",
    course: "Power BI Internship",
    avatar: "SR",
    rating: 5,
    feedback:
      "My experience in this program was highly rewarding and insightful. The training was well-structured, practical, and focused on real-world applications of data analytics and business intelligence. Through hands-on projects and expert guidance, I was able to strengthen my skills in Power BI, data modeling, DAX, and dashboard development. The support and mentorship provided throughout the internship helped me gain confidence in solving business problems using data-driven approaches. I am especially grateful to Infinity Code Nexus and Anand Kumar Sir for their continuous guidance, encouragement, and commitment to helping learners grow professionally.",
  },

  {
    id: 2,
    name: "Kanamathareddy Chethan Reddy",
    role: "B.Tech Student",
    course: "Power BI Internship",
    avatar: "CR",
    rating: 5,
    feedback:
      "The Power BI Internship Program at Infinity Code Nexus was a valuable learning experience that helped me strengthen my skills in data analytics and business intelligence. The practical assignments, project-based learning approach, and continuous guidance from Anand Sir enabled me to build confidence in creating professional Power BI dashboards and applying data-driven decision-making techniques. I am grateful to Infinity Code Nexus for providing this opportunity and helping me enhance my technical and analytical skills.",
  },

  {
    id: 3,
    name: "Macha Ramyasree",
    role: "B.Tech Student",
    course: "Power BI Master Class",
    avatar: "MR",
    rating: 5,
    feedback:
      "My learning experience with Infinity Code Nexus was excellent. The program provided hands-on training in Power BI, data analysis, DAX, and dashboard development, helping me build confidence and complete my first end-to-end analytics project successfully. I am grateful to my mentor, Mr. Anand Kumar Anamaina, for his guidance and support throughout the journey.",
  },

  {
    id: 4,
    name: "Student",
    role: "Engineering Student",
    course: "Power BI Master Class",
    avatar: "ES",
    rating: 5,
    feedback:
      "The sessions were very interactive and beginner-friendly. The practical approach to dashboard development made Power BI easy to understand and apply to real-world business scenarios.",
  },

  {
    id: 5,
    name: "Student",
    role: "Power BI Learner",
    course: "Power BI Internship",
    avatar: "PL",
    rating: 5,
    feedback:
      "The internship helped me understand Power Query, DAX, data modeling, and dashboard creation through practical assignments. The mentor support was excellent throughout the program.",
  },

  {
    id: 6,
    name: "Student",
    role: "B.Tech Student",
    course: "Power BI Master Class",
    avatar: "BT",
    rating: 5,
    feedback:
      "Every concept was explained clearly with live demonstrations. The real-world datasets and projects made learning enjoyable and helped me gain confidence in Power BI.",
  },

  {
    id: 7,
    name: "Student",
    role: "MBA Student",
    course: "Power BI Master Class",
    avatar: "MB",
    rating: 5,
    feedback:
      "The structured curriculum and project-based learning approach helped me understand business intelligence concepts and dashboard design from scratch.",
  },

  {
    id: 8,
    name: "Student",
    role: "Data Analytics Learner",
    course: "Power BI Internship",
    avatar: "DA",
    rating: 5,
    feedback:
      "The internship exceeded my expectations. I gained practical experience in Power BI and learned how to create interactive dashboards for business reporting.",
  },

  {
    id: 9,
    name: "Student",
    role: "Engineering Student",
    course: "Power BI Master Class",
    avatar: "EN",
    rating: 5,
    feedback:
      "One of the best learning experiences I have had. The mentor explained every topic patiently and encouraged us to complete real-world projects independently.",
  },

  {
    id: 10,
    name: "Student",
    role: "Power BI Learner",
    course: "Power BI Internship",
    avatar: "PB",
    rating: 5,
    feedback:
      "The training was practical, interactive, and industry-focused. I now feel confident creating professional Power BI dashboards and presenting insights effectively.",
  },
];

export default testimonials;